export default {
  providers: [
    {
      domain: "https://equipped-kid-12.clerk.accounts.dev",
      applicationID: "convex",
    }
  ]
}