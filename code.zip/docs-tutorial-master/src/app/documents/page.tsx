const DocumentsPage = () => {
  return ( 
    <div>Documents Page</div>
   );
}
 
export default DocumentsPage;